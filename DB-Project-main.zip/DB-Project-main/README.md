# DB-Project
Information Security Curricular Unit Practical Projet (Computer Engineering Bachelor)
Development of a system to manage for an enterprise called "Game-On" using PostgreSQL, plpgSQL and JPA. 
This project is mainly focused on practising DB management and Isolation-Levels.
